# Use i3 as the window manager instead of Kwin 
export KDEWM=/usr/bin/i3
